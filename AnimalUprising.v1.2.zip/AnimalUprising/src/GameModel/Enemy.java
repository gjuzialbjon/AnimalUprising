package GameModel;

public interface Enemy
{
	public static final boolean ally = false;
	public static final boolean enemy = true;
	
}
