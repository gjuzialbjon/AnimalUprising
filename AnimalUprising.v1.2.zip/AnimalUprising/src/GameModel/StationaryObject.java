package GameModel;

public class StationaryObject {

}
