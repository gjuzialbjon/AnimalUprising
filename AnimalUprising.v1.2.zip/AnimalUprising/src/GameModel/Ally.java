package GameModel;

public interface Ally 
{
	public static final boolean ally = true;
	public static final boolean enemy = false;
	
}
