package GameModel;

public interface Ranged
{
	public static final int range = 30;
}
