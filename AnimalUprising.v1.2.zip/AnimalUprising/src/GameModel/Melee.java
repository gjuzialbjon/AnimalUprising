package GameModel;

public interface Melee
{
	public static final int range = 12;
}
