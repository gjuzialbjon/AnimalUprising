/*
 * Author: Bora Ecer
 * Date: 16.12.2017
 * Class for background music
 */
package dev.animaluprising.GameControl;

import java.io.InputStream;
import sun.audio.*;

public class SoundManager 
{
	public InputStream backgroundStream;
    public AudioStream backgroundMusic;
    public InputStream backgroundStream1;
    public AudioStream backgroundMusic1;
	public SoundManager()
	{
		try {
			backgroundStream = getClass().getResourceAsStream("/Sounds/backgroundMusic.wav");
			backgroundMusic = new AudioStream(backgroundStream);
			
			backgroundStream1 = getClass().getResourceAsStream("/Sounds/prep.wav");
			backgroundMusic1 = new AudioStream(backgroundStream1);
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	public void play()
	{
		AudioPlayer.player.start(backgroundMusic);
	}
	
	
	public void stop()
	{
		AudioPlayer.player.stop(backgroundMusic);
	}
}
