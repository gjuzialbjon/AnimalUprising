/*
 * Author: Bora Ecer
 * Date: 1 November 2017
 * Version: v1
 * Interface for representing the allied classes.
 * interface will be improved. It is a non-factor for now.
 */

package GameModel;

public interface Ally 
{

	public static final boolean ally = true;
	public static final boolean enemy = false;
	
}
