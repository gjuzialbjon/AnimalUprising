/*
 * Author: Bora Ecer
 * Date: 1 November 2017
 * Version: v1
 * Interface for representing the enemy classes.
 * interface will be improved. It is a non-factor for now.
 */

package GameModel;

public interface Enemy
{

	public static final boolean ally = false;
	public static final boolean enemy = true;
	
}
