/*
 * Author: Bora Ecer
 * Date: 1 November 2017
 * Version: v1
 * Interface for representing the melee classes.
 * interface will be improved. It is a non-factor for now.
 */

package GameModel;

public interface Melee
{

	public static final int range = 12;
}
