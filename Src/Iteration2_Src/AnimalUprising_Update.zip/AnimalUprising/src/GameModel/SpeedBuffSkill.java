package GameModel;

import java.awt.Graphics;
import java.awt.Rectangle;

import GameControl.GameManager;

public class SpeedBuffSkill extends GameObject implements Skills	
{
	public SpeedBuffSkill(float posX, float posY, int width, int height, int health, GameManager gameManager) {
		super(posX, posY, width, height, health, gameManager);
		// TODO Auto-generated constructor stub
	}

	public static void cast() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void render(Graphics g) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public Rectangle getCollisionRectangle() {
		// TODO Auto-generated method stub
		return null;
	}

}
