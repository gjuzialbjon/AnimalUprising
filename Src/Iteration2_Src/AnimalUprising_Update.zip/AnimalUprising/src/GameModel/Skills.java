package GameModel;

import java.awt.Rectangle;

public interface Skills {
	

	
	public Rectangle getCollisionRectangle();
}
