package UIManagement;

public class ShopMenu {

}
