package GameControl.States;

import java.awt.Graphics;

import GameControl.GameManager;

public class PauseState extends States
{

	public PauseState(GameManager gameManager) {
		super(gameManager);
	}
	
	@Override
	public void update() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void render(Graphics graphics) {
		// TODO Auto-generated method stub
		
	}

}
