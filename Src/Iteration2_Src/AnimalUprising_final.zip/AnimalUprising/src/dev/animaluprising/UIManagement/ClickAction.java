package dev.animaluprising.UIManagement;

public interface ClickAction {
	public void onClick();
}
