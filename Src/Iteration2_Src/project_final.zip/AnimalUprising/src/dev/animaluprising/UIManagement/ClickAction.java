package dev.animaluprising.UIManagement;
/**
 * @author Ata Gun Ogun
 */
public interface ClickAction {
	public void onClick();
}
